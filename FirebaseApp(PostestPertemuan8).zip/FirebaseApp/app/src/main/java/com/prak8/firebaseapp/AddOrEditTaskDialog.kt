package com.prak8.firebaseapp

import android.app.DatePickerDialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.firebase.database.DatabaseReference
import com.prak8.firebaseapp.databinding.DialogAddTaskBinding
import java.util.Calendar

class AddOrEditTaskDialog(context: Context, private val tasksRef: DatabaseReference, private val task: Task? = null) : AlertDialog(context) {

    private lateinit var binding: DialogAddTaskBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DialogAddTaskBinding.inflate(LayoutInflater.from(context))
        setContentView(binding.root)

        if (task != null) {
            binding.etTaskTitle.setText(task.title)
            binding.etTaskDescription.setText(task.description)
            binding.tvDeadline.text = task.deadline
        }

        binding.tvDeadline.setOnClickListener {
            showDatePicker()
        }

        binding.btnCancel.setOnClickListener {
            dismiss()
        }

        binding.btnSave.setOnClickListener {
            saveTask()
        }
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(context, {
            _, selectedYear, selectedMonth, selectedDay ->
            binding.tvDeadline.text = "$selectedDay/${selectedMonth + 1}/$selectedYear"
        }, year, month, day).show()
    }

    private fun saveTask() {
        val title = binding.etTaskTitle.text.toString().trim()
        val description = binding.etTaskDescription.text.toString().trim()
        val deadline = binding.tvDeadline.text.toString().trim()

        if (title.isEmpty()) {
            Toast.makeText(context, "Title cannot be empty", Toast.LENGTH_SHORT).show()
            return
        }

        val taskId = task?.id ?: tasksRef.push().key
        val newTask = Task(taskId, title, description, deadline, task?.isCompleted ?: false)

        if (taskId != null) {
            tasksRef.child(taskId).setValue(newTask).addOnCompleteListener {
                if (it.isSuccessful) {
                    val message = if (task == null) "Tugas ditambahkan" else "Tugas diperbarui"
                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                    dismiss()
                } else {
                    Toast.makeText(context, "Failed to save task", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}