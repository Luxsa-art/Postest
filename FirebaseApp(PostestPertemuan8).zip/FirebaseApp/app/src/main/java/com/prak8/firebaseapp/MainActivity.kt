package com.prak8.firebaseapp

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.database.*
import com.prak8.firebaseapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var tasksRef: DatabaseReference
    private lateinit var taskAdapter: TaskAdapter
    private val taskList = mutableListOf<Task>()
    private var childEventListener: ChildEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        tasksRef = FirebaseDatabase.getInstance().getReference("tasks")

        setupRecyclerView()
        setupFab()
    }

    override fun onResume() {
        super.onResume()
        attachDatabaseReadListener()
    }

    override fun onPause() {
        super.onPause()
        detachDatabaseReadListener()
    }

    private fun setupRecyclerView() {
        taskAdapter = TaskAdapter(taskList, this::showEditTaskDialog, this::deleteTask, this::updateTaskStatus)
        binding.rvTasks.layoutManager = LinearLayoutManager(this)
        binding.rvTasks.adapter = taskAdapter
    }

    private fun attachDatabaseReadListener() {
        if (childEventListener == null) {
            childEventListener = object : ChildEventListener {
                override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                    val task = snapshot.getValue(Task::class.java)
                    if (task != null && task.id != null && taskList.none { it.id == task.id }) {
                        taskList.add(task)
                        taskAdapter.updateTasks(taskList)
                        updateEmptyState()
                    }
                }

                override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                    val updatedTask = snapshot.getValue(Task::class.java)
                    if (updatedTask != null && updatedTask.id != null) {
                        val index = taskList.indexOfFirst { it.id == updatedTask.id }
                        if (index != -1) {
                            taskList[index] = updatedTask
                            taskAdapter.updateTasks(taskList)
                        }
                    }
                }

                override fun onChildRemoved(snapshot: DataSnapshot) {
                    val removedTask = snapshot.getValue(Task::class.java)
                    if (removedTask != null && removedTask.id != null) {
                        val index = taskList.indexOfFirst { it.id == removedTask.id }
                        if (index != -1) {
                            taskList.removeAt(index)
                            taskAdapter.updateTasks(taskList)
                            updateEmptyState()
                        }
                    }
                }

                override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@MainActivity, "Gagal memuat tugas.", Toast.LENGTH_SHORT).show()
                }
            }
            tasksRef.addChildEventListener(childEventListener!!)
        }
    }

    private fun detachDatabaseReadListener() {
        childEventListener?.let {
            tasksRef.removeEventListener(it)
            childEventListener = null
        }
        taskList.clear()
        taskAdapter.updateTasks(emptyList())
        updateEmptyState()
    }

    private fun updateEmptyState() {
        binding.llEmptyState.visibility = if (taskList.isEmpty()) View.VISIBLE else View.GONE
        binding.rvTasks.visibility = if (taskList.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun setupFab() {
        binding.fabAddTask.setOnClickListener {
            showAddTaskDialog()
        }
    }

    private fun showAddTaskDialog() {
        AddOrEditTaskDialog(this, tasksRef).show()
    }

    private fun showEditTaskDialog(task: Task) {
        AddOrEditTaskDialog(this, tasksRef, task).show()
    }

    private fun deleteTask(task: Task) {
        task.id?.let { taskId ->
            tasksRef.child(taskId).removeValue().addOnSuccessListener {
                Snackbar.make(binding.root, "Tugas dihapus", Snackbar.LENGTH_LONG).show()
            }.addOnFailureListener {
                Snackbar.make(binding.root, "Gagal menghapus tugas", Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateTaskStatus(task: Task, isChecked: Boolean) {
        task.id?.let {
            val updatedTask = task.copy(isCompleted = isChecked)
            tasksRef.child(it).setValue(updatedTask)
        }
    }
}