package com.prak8.firebaseapp

data class Task(
    val id: String? = null,
    val title: String? = null,
    val description: String? = null,
    val deadline: String? = null,
    var isCompleted: Boolean = false
)