package com.prak8.firebaseapp

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.prak8.firebaseapp.databinding.ItemTaskBinding

class TaskAdapter(
    private var tasks: List<Task>,
    private val onEditClick: (Task) -> Unit,
    private val onDeleteClick: (Task) -> Unit,
    private val onTaskChecked: (Task, Boolean) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ItemTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TaskViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(tasks[position])
    }

    override fun getItemCount(): Int = tasks.size

    fun updateTasks(tasks: List<Task>) {
        this.tasks = tasks
        notifyDataSetChanged()
    }

    inner class TaskViewHolder(private val binding: ItemTaskBinding) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.cbTask.setOnClickListener {
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    val task = tasks[adapterPosition]
                    onTaskChecked(task, binding.cbTask.isChecked)
                }
            }
            binding.ivDelete.setOnClickListener {
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    onDeleteClick(tasks[adapterPosition])
                }
            }
            itemView.setOnClickListener {
                if (adapterPosition != RecyclerView.NO_POSITION) {
                    onEditClick(tasks[adapterPosition])
                }
            }
        }

        fun bind(task: Task) {
            binding.tvTaskTitle.text = task.title
            binding.tvTaskDescription.text = task.description
            binding.tvTaskDeadline.text = task.deadline
            binding.cbTask.isChecked = task.isCompleted
            updateTaskAppearance(task.isCompleted)
        }

        private fun updateTaskAppearance(isCompleted: Boolean) {
            if (isCompleted) {
                binding.tvTaskTitle.paintFlags = binding.tvTaskTitle.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                binding.tvTaskDescription.visibility = View.GONE
                binding.tvTaskDeadline.visibility = View.GONE
            } else {
                binding.tvTaskTitle.paintFlags = binding.tvTaskTitle.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                binding.tvTaskDescription.visibility = View.VISIBLE
                binding.tvTaskDeadline.visibility = View.VISIBLE
            }
        }
    }
}